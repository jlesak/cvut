using System.Threading.Tasks;
using Microsoft.Bot.Builder;

namespace Trask.Bot.EventBot.Models
{
//    public interface ITopic
//    {
//        string Name { get; set; }
//        Task<bool> StartTopic(IBotContext context);
//        Task<bool> ContinueTopic(IBotContext context);
//        Task<bool> ResumeTopic(IBotContext context);
//    }
}