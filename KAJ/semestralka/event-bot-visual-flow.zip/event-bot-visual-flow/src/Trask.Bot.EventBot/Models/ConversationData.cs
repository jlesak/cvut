namespace Trask.Bot.EventBot.Models
{
//    /// <summary>
//    /// Persisted conversation data
//    /// </summary>
//    public class ConversationData : StoreItem
//    {
//        public ITopic ActiveTopic { get; set; }
//    }
}