namespace Trask.Bot.EventBot.Options
{
    public class NlpQnAProviderOptions
    {
        public string ServiceEndpoint { get; set; }
        public string SvdMatch { get; set; }
        public string ModelName { get; set; }
    }
}
