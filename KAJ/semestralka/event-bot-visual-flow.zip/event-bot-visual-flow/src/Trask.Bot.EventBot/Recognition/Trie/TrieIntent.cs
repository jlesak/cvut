namespace Trask.Bot.EventBot.Recognition.Trie
{
    public class TrieIntent : IHasName
    {
        public string Name { get; set; }
    }
}