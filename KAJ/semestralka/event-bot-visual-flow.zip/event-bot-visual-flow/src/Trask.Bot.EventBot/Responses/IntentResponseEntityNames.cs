namespace Trask.Bot.EventBot.Responses
{
    public class IntentResponseEntityNames
    {
        public static string Response = "Response";
        
    }
}