** EventBot **

Pokud bude nevalidni certifikat nastavit si lokalne:

git config --local http.sslVerify false

Nastavit si jmeno a email:

git config --local user.name "your name"

git config --local user.email "your email"