/**
 * jQuery json-viewer
 * @author: Alexandre Bodelot <alexandre.bodelot@gmail.com>
 */

  /**
   * Check if arg is either an array with at least 1 element, or a dict with at least 1 key
   * @return boolean
   */
  function is_collapsible(arg)
  {
    return arg instanceof Object && Object.keys(arg).length > 0;
  }

  /**
   * Transform json object into html representation
   * @return string
   */
  function json2html(json)
  {
    let html = '';
    if (json instanceof Array) {
      if (json.length > 0) {
        html += '[<ol class="json-array">';
        for (const i in json) {
          html += '<li>';

          if (is_collapsible(json[i])){
            html += '<a href class="json-toggle"></a>';
          }
          html += json2html(json[i]);

          if (i < json.length - 1) {
            html += ',';
          }
          html += '</li>';
        }
        html += '</ol>]';
      }
      else {
        html += '[]';
      }
    }

    else if (typeof json === 'string') {
      html += '<span class="json-string">"' + json + '"</span>';
    }
    else if (typeof json === 'number' || typeof json === 'boolean' || json === null) {
      html += '<span class="json-literal">' + json + '</span>';
    }

    else {
      let key_count = Object.keys(json).length;
      if (key_count > 0) {
        html += '{<ul class="json-dict">';
        for (const i in json) {
          if (json.hasOwnProperty(i)) {
            html += '<li>';

            if (is_collapsible(json[i])) {
              html += '<a href class="json-toggle"></a>';
            }
            html += i + ': ' + json2html(json[i]);

            if (--key_count > 0) {
              html += ',';
            }
            html += '</li>';
          }
        }
        html += '</ul>}';
      }
      else {
        html += '{}';
      }
    }
    return html;
  }

  /**
   * jQuery plugin method
   */
  $.fn.json_viewer = function(json) {
    // Transform to HTML
    let html = json2html(json);
    if (is_collapsible(json)) {
      html = '<a href class="json-toggle"></a>' + html;
    }
    $(this).unbind('click');

    // Insert HTML in target DOM element
    $.fn.html.call($(this), html);

    // Bind click on toggle buttons
    $(this).on('click', 'a.json-toggle', function() {
      const target = $(this).toggleClass('collapsed').siblings('ul.json-dict, ol.json-array');
      target.toggle();
      const count = target.children('li').length;
      if (target.is(':visible')) {
        target.siblings('.json-placeholder').remove();
      }
      else {
        const placeholder = count + (count > 1 ? ' items' : ' item');
        target.after('<span class="json-placeholder">' + placeholder + '</span>');
      }
      return false;
    });
  };
