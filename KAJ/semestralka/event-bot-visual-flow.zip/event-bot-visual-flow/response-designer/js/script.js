var rootList = [];
document.addEventListener('DOMContentLoaded', () => {

    const targetUl = document.querySelector('.intents-list');
    const initElement = new IntentResponse(targetUl, '');
    rootList.push(initElement);

    document.querySelector('.add-intent-button').addEventListener('click', function () {
        const targetUl = document.querySelector('.intents-list');
        const el = new IntentResponse(targetUl, '');
        rootList.push(el);
    });



    const builder = new JsonBuilder();
    const loader = new FileLoader();
});