class TrieNode {
    constructor(name) {
        this.name = name;
        this.children = [];
    }

    addChildNode(childTrieNode){
        this.children.push(childTrieNode);
    }
}

class ResponseDefinition{
    constructor(intentValue, response){
        this.topic = 'TestAgent';
        this.intent = intentValue;
        this.state = null;
        this.channel = null;
        this.locale = null;
        this.domain = null;
        this.payloadType = 'text';
        this.payload = response;
        this.validFrom = null;
        this.validTo = null;
        this.id = `response-definition:${this.generateGuid()}`;

    }
    generateGuid() {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000)
                .toString(16)
                .substring(1);
        }
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
            s4() + '-' + s4() + s4() + s4();
    }
}

class JsonBuilder{
    constructor(){
        let responses = [];
        let intents = [];
        $('#export-responses').on('click', () => {
            this.makeJsons();
            $('#json-renderer').json_viewer(this.responses);
            JsonBuilder.copyToClipboard(JSON.stringify(this.responses));
        });
        $('#export-intent-tree').on('click', () => {
            this.makeJsons();
            $('#json-renderer').json_viewer(this.intents);
            JsonBuilder.copyToClipboard(JSON.stringify(this.intents));
        });
    }

    makeJsons() {
        this.responses = [];
        this.intents = [];
        const rootIntent = new TrieNode("null");
        for (let i = 0; i < rootList.length; i++) {
            const child = rootList[i];
            rootIntent.addChildNode(this.parseIntentResponse(child));
        }
        this.intents.push(rootIntent);
    }

    static copyToClipboard(str){
        const el = document.createElement('textarea');  // Create a <textarea> element
        el.value = str;                                 // Set its value to the string that you want copied
        el.setAttribute('readonly', '');                // Make it readonly to be tamper-proof
        el.style.position = 'absolute';
        el.style.left = '-9999px';                      // Move outside the screen to make it invisible
        document.body.appendChild(el);                  // Append the <textarea> element to the HTML document
        const selected =
            document.getSelection().rangeCount > 0        // Check if there is any content selected previously
                ? document.getSelection().getRangeAt(0)     // Store selection if found
                : false;                                    // Mark as false to know no selection existed before
        el.select();                                    // Select the <textarea> content
        document.execCommand('copy');                   // Copy - only works as a result of a user action (e.g. click events)
        document.body.removeChild(el);                  // Remove the <textarea> element
        if (selected) {                                 // If a selection existed before copying
            document.getSelection().removeAllRanges();    // Unselect everything on the HTML document
            document.getSelection().addRange(selected);   // Restore the original selection
        }
    }

    parseIntentResponse(intentResponse){
        let prevIntent = intentResponse.prevIntentSpan.textContent;
        let nodeIntent = intentResponse.intentSelect.value;
        let intentValue = `${prevIntent}${nodeIntent}`;
        const trieNode = new TrieNode(nodeIntent);

        //responses
        for (let i = 0; i < intentResponse.responsesArray.length-1; i++) {
            this.responses.push(new ResponseDefinition(intentValue, intentResponse.responsesArray[i].value));
        }

        //intents
        const children = intentResponse.subintents;
        if (children.length === 0){
            return trieNode;
        }
        for (let i = 0; i < children.length; i++) {
            trieNode.addChildNode(this.parseIntentResponse(children[i]));
        }
        return trieNode;
    }
}